def process_retry_queue():
    print('Processing retry queue...')
