def auto_sync_enabled_shops():
    print('Pulling data from shops to HQ...')
