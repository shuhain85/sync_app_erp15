def sync_hq_to_shops():
    print('Pushing data from HQ to shops...')
