from setuptools import setup, find_packages

setup(
    name='sync_erp_15',
    version='0.0.1',
    description='ERPNext HQ-Shop Synchronization Platform',
    author='Your Company',
    author_email='support@example.com',
    packages=find_packages(),
    zip_safe=False,
    include_package_data=True,
    install_requires=[]
)